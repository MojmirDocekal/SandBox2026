#!/usr/bin/env python3
"""Simple terminal timer with space to start/pause and enter to end."""

import time
import sys
import tty
import termios
import select


def format_time(seconds):
    """Format seconds to MM:SS format."""
    mins = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{mins:02d}:{secs:02d}"


def main():
    """Run the timer application."""
    elapsed = 0
    running = False
    paused_time = 0
    start_time = None
    
    print("\n" + "="*40)
    print("     SIMPLE TIMER")
    print("="*40)
    print("\nControls:")
    print("  SPACE - Start / Pause")
    print("  ENTER - End Timer")
    print("\n" + "-"*40 + "\n")
    print("Press SPACE to start...")
    
    # Set terminal to raw mode
    fd = sys.stdin.fileno()
    original_settings = termios.tcgetattr(fd)
    
    try:
        tty.setraw(fd)
        
        while True:
            # Display current time
            sys.stdout.write(f"\r{format_time(elapsed)} ")
            sys.stdout.flush()
            
            # Non-blocking check for input with 50ms timeout
            if select.select([sys.stdin], [], [], 0.05)[0]:
                key = sys.stdin.read(1)
                
                if key == ' ':  # Space to start/pause
                    if not running:
                        # Start or resume
                        running = True
                        start_time = time.time() - paused_time
                        sys.stdout.write("\r" + " "*50 + "\n")
                        sys.stdout.flush()
                        sys.stdout.write("Timer running... (SPACE to pause, ENTER to end)\n")
                        sys.stdout.flush()
                    else:
                        # Pause
                        running = False
                        paused_time = elapsed
                        sys.stdout.write("\r" + " "*50 + "\n")
                        sys.stdout.flush()
                        sys.stdout.write(f"Timer paused at {format_time(elapsed)} (SPACE to resume, ENTER to end)\n")
                        sys.stdout.flush()
                
                elif key == '\r' or key == '\n':  # Enter to end
                    sys.stdout.write("\r" + " "*50 + "\n")
                    sys.stdout.flush()
                    print(f"✓ Timer ended at: {format_time(elapsed)}")
                    print("="*40 + "\n")
                    break
            
            # Update elapsed time if running
            if running:
                elapsed = time.time() - start_time
    
    except KeyboardInterrupt:
        sys.stdout.write("\r" + " "*50 + "\n")
        sys.stdout.flush()
        print("✗ Timer interrupted")
        print("="*40 + "\n")
    
    finally:
        # Restore terminal settings
        termios.tcsetattr(fd, termios.TCSADRAIN, original_settings)


if __name__ == "__main__":
    main()
